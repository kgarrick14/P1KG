﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace OfficialFootballAPI
{
	public class Players : Teams
	{
		SqlConnection con = new SqlConnection("server=localhost;database=footballDB;user id=sa;password=Strong.Pwd-123");
        //public Players()
        //{
        //}

        public List<Players> ViewPlayers()
        {
            SqlCommand cmd = new SqlCommand("select * from Players, Teams Where Players.playerTeamID = Teams.teamID", con);
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            List<Players> plist = new List<Players>();
            while (rd.Read())
            {
                plist.Add(new Players()
                {
                    playerId = Convert.ToInt32(rd[0]),
                    playerName = rd[1].ToString(),
                    playerPosition = rd[2].ToString(),
                    playerTeamID = Convert.ToInt32(rd[3])
                    //country, ID , teamName
                });
            }
            rd.Close();
            con.Close();
            return plist;
        }



        public Players GetPlayerByName(string playerName)
        {
            SqlCommand cmd = new SqlCommand("Select teamID, teamName, country, playerId, playerName, playerPosition From Players Join Teams on Players.playerTeamId = Teams.teamID WHERE playerName = @pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);
            

            SqlDataReader rd = null;
            try
            {

                con.Open();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {

                    Players  p = new Players()

                    {

                        teamID = Convert.ToInt32(rd[0]),
                        teamName = rd[1].ToString(),
                        country = rd[2].ToString(),
                        playerId = Convert.ToInt32(rd[3]),
                        playerName = rd[4].ToString(),
                        playerPosition = rd[5].ToString(),
                        playerTeamID = Convert.ToInt32(rd[0])

                    };
                    return p;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Wrong name, please try again");
                }




            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }
        }

        public List <Players> GetAllPlayersByPosition(string playerPosition)
        {
            SqlCommand cmd = new SqlCommand("Select teamID, teamName, country, playerId, playerName, playerPosition From Players Join Teams on Players.playerTeamId = Teams.teamID WHERE playerPosition = @Position", con);
            cmd.Parameters.AddWithValue("@Position", playerPosition);

            //SqlDataReader rd = null;
            //try
            //{

            //    con.Open();
            //    rd = cmd.ExecuteReader();
            //    if (rd.Read())
            //    {

            //        Players pq = new Players()
            //        {

            //            teamID = Convert.ToInt32(rd[0]),
            //            teamName = rd[1].ToString(),
            //            country = rd[2].ToString(),
            //            playerId = Convert.ToInt32(rd[3]),
            //            playerName = rd[4].ToString(),
            //            playerPosition = rd[5].ToString()

            //        };
            //        return pq;
            //    }
            //    else
            //    {
            //        rd.Close();
            //        con.Close();
            //        throw new Exception("Error");
            //    }

            //}
            //catch (Exception es)
            //{
            //    throw new Exception(es.Message);
            //}
            //finally
            //{
            //    rd.Close();
            //    con.Close();
            //}

            //Players pq = new Players();
            //con.Open();
            //SqlDataReader rd = cmd.ExecuteReader();
            //try
            //{
            //     while (rd.Read())
            //    {
            //        pq.teamID = (int)rd[0];
            //        pq.teamName = rd[1].ToString();
            //        pq.country = rd[2].ToString();
            //        pq.playerId = (int)rd[3];
            //        pq.playerName = rd[4].ToString();
            //        pq.playerPosition = rd[5].ToString();
            //    }
            //    return pq;
            //}
            //catch (Exception es)
            //{
            //    rd.Close();
            //    con.Close();
            //    throw new Exception(es.Message);
            //}
            //finally
            //{
            //    rd.Close();
            //    con.Close();

            //}

            SqlDataReader rd = null;
            try
            {
                List<Players> posList = new List<Players>();
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {

                    posList.Add(new Players()
                    {

                        teamID = Convert.ToInt32(rd[0]),
                        teamName = rd[1].ToString(),
                        country = rd[2].ToString(),
                        playerId = Convert.ToInt32(rd[3]),
                        playerName = rd[4].ToString(),
                        playerPosition = rd[5].ToString()

                    });

                }

                //rd.Close();
                con.Close();
                return posList;



            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }


        }

        public string AddNewPlayer (Players play)
        {
            SqlCommand cmd = new SqlCommand("insert into Players values(@playerId, @playerName, @playerPosition, @playerTeamID)", con);
            cmd.Parameters.AddWithValue("@playerId", play.playerId);
            cmd.Parameters.AddWithValue("@playerName", play.playerName);
            cmd.Parameters.AddWithValue("@playerPosition", play.playerPosition);
            cmd.Parameters.AddWithValue("@playerTeamID", play.playerTeamID);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "Player added Successfully";
        }

        public string UpdatePlayer(Players changes)
        {
            SqlCommand cmd = new SqlCommand("update Players set playerTeamID = @ID where playerName = @Name", con);
            cmd.Parameters.AddWithValue("@ID", changes.playerTeamID);
            cmd.Parameters.AddWithValue("@Name", changes.playerName);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "Plaayer moved to New Team";
        }

        public string DeletePlayer(string playerName)
        {
            SqlCommand cmd = new SqlCommand("delete from Players where playerName = @Name", con);
            cmd.Parameters.AddWithValue("Name", playerName);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result == 1)
            {
                return "Player Deleted Successfully";
            }
            throw new Exception("Player not found");

        }







    }
}

