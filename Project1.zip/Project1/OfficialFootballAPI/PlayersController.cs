﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OfficialFootballAPI
{
    public class PlayersController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }
        Players pObj = new Players();

        [HttpGet]
        [Route("plist")]
        public IActionResult GetPlayers()
        {
            return Ok(pObj.ViewPlayers());
        }

        [HttpGet]
        [Route("plist/[[GetPlayerByName]]/{playerName}")]
        public IActionResult PlayerByName(string playerName)
        {
            try
            {
                return Ok(pObj.GetPlayerByName(playerName));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }
        }


        [HttpGet]
        [Route("plist/[[GetAllPlayersByPosition]]/{playerPosition}")]
        public IActionResult PlayersbyPosition(string playerPosition)
        {
            try
            {
                return Ok(pObj.GetAllPlayersByPosition(playerPosition));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }

        }


        [HttpPost]
        [Route("plist/add")]
        public IActionResult AddPlayer(Players play)
        {
            return Ok(pObj.AddNewPlayer(play));
        }


        [HttpPut]
        [Route("plist/edit")]
        public IActionResult EditPlayer(Players ep)
        {
            return Ok(pObj.UpdatePlayer(ep));
        }
        [HttpDelete]
        [Route("plist/delete")]
        public IActionResult DeletePlayer( string playerName)
        {
            try
            {
                return Ok(pObj.DeletePlayer(playerName));
            }
            catch(Exception es)
            {
                return BadRequest(es.Message); 
            }
        }


    }
}

