﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OfficialFootballAPI
{
    public class Teams
    {
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public int teamID { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string teamName { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string country { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public int playerId { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string playerName { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string playerPosition { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public int  playerTeamID { get; set; }


        SqlConnection con = new SqlConnection("server=localhost;database=footballDB;user id=sa;password=Strong.Pwd-123");

        public List<Teams> ShowAllTeams()
        {
            SqlCommand cmd = new SqlCommand("select * from Teams", con);
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            List<Teams> teamlist = new List<Teams>();
            while (rd.Read())
            {
                teamlist.Add(new Teams()
                {
                    teamID = Convert.ToInt32(rd[0]),
                    teamName = rd[1].ToString(),
                    country = rd[2].ToString()
                });
            }
            rd.Close();
            con.Close();
            return teamlist;
        }
        public List <Teams> GetTeamByName(string teamName)
        {
            SqlCommand cmd = new SqlCommand("Select teamID, teamName, country, playerId, playerName, playerPosition From Teams  Join Players on Teams.teamID = Players.playerTeamId Where teamName = @tname", con);
            cmd.Parameters.AddWithValue("@tname", teamName);
            SqlDataReader rd = null;
            //int playerId = 0;
            //string playerName = null;
            //string playerPosition = null;
            //SqlDataReader rd = cmd.ExecuteReader;
            try
            {
                List<Teams> fullTeam = new List<Teams>();
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    
                    fullTeam.Add(new Teams()
                    {
                       
                        teamID = Convert.ToInt32(rd[0]),
                        teamName = rd[1].ToString(),
                        country = rd[2].ToString(),
                        playerId = Convert.ToInt32(rd[3]),
                        playerName = rd[4].ToString(),
                        playerPosition = rd[5].ToString(),
                        playerTeamID = Convert.ToInt32(rd[0])

                    });
                    
                }
                
                rd.Close();
                con.Close();
                return fullTeam;

                
                
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }


        }

        public string AddTeam(Teams newTeam)
        {
            SqlCommand cmd = new SqlCommand("insert into Teams values(@teamID, @teamName, @country)", con);
            cmd.Parameters.AddWithValue("@teamID", newTeam.teamID);
            cmd.Parameters.AddWithValue("@teamName", newTeam.teamName);
            cmd.Parameters.AddWithValue("@country", newTeam.country);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "New team created successfully!";
        }



    }

    

}

