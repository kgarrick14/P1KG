﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OfficialFootballAPI
{
    public class TeamsController : Controller
    {
        //GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        Teams tObj = new Teams();

        [HttpGet]
        [Route("teamlist")]
        public IActionResult SeeAllTeams()
        {
            return Ok(tObj.ShowAllTeams());
        }

        [HttpGet]
        [Route("teamlist/{teamName}")]
        public IActionResult FindTeam(string teamName)
        {
            try
            {
                return Ok(tObj.GetTeamByName(teamName));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }
        }

        [HttpPost]
        [Route("teamlist/add")]
        public IActionResult AddTeam(Teams newTeam)
        {
            return Ok(tObj.AddTeam(newTeam));
        }
    }
}

